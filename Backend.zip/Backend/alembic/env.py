from logging.config import fileConfig
import sys
from pathlib import Path

from sqlalchemy import engine_from_config, pool
from alembic import context

# Tambahkan root project ke sys.path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# Import Base dan settings
from app.db.base import Base
from app.core.config import settings

# Import model supaya Alembic deteksi
from app.models import *  # noqa: F401, F403

config = context.config


# ============================================================
# Normalisasi URL (sama seperti di app/db/session.py)
# ============================================================
def _normalisasi_url(url: str) -> str:
    if not url or not url.strip():
        raise ValueError(
            "DATABASE_URL kosong. Pastikan environment variable sudah di-set."
        )
    url = url.strip()

    # mysql:// → mysql+pymysql://
    if url.startswith("mysql://"):
        url = url.replace("mysql://", "mysql+pymysql://", 1)

    # Tambah charset kalau belum ada
    if "charset" not in url:
        separator = "&" if "?" in url else "?"
        url = f"{url}{separator}charset=utf8mb4"

    return url


# Override URL dari settings (yang sudah dinormalisasi)
config.set_main_option("sqlalchemy.url", _normalisasi_url(settings.DATABASE_URL))

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()